
<script src="{{asset('admin_dash_theme/js/bootstrap.js')}}"></script>
<script src="{{asset('admin_dash_theme/js/proton.js')}}"></script>
{{-- script for ck editor--}}
<script src="{{ asset('vendor/unisharp/laravel-ckeditor/ckeditor.js') }}"></script>
<script>CKEDITOR.replace( 'editor1' );</script>
