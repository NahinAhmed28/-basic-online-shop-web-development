


<!-- footer -->
<div class="footer">
    <p >&copy; 2018 Point Of Sale. All Rights Reserved | Developed by <a href="" target="_blank"><strong><i>Sun Ibne Sazzad</i></strong></a></p>
</div>
<!-- //footer -->

<style>
    div.footer{
        position:fixed;
        left:0px;
        bottom:0px;
        height:30px;
        width:100%;
    }
</style>