
<p> This project need minimum PHP version 7.1.4 </p>
<p> Check the composer.jason file first to see what are the minimum requirements to run this project. </p>
<br>
<p> 1.Clone the Project </p>
<p> 2.Copy env.example and paste in same folder by renaming it .env file </p>
<p> 3.Set the database name in .env file same as you created in your phpMyAdmin. Set user name as root and keep password as blank. </p>
<p> 4.Open Command Prompt window inside project folder. </p>
<p> 5.Run these commands </P>
<p> a.Composer update </p>
<p> b.php artisan key:generate </p>
<p> c.php artisan migrate </p>
<p> d.php artisan db:seed </p>
<p> e.php artisan serve </p>
<p> 6.This is it for Web part. </p>
<p> 7.For testing the Api part first run command "php artisan passport:install" then "php artisan serve".</p>