
<script src="<?php echo e(asset('admin_dash_theme/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('admin_dash_theme/js/proton.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
<script>CKEDITOR.replace( 'editor1' );</script>
