<!DOCTYPE>
<html lang="en">

<?php echo $__env->make('dash_include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="dashboard-page">

<?php echo $__env->make('dash_include.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="wrapper scrollable">


    <?php echo $__env->make('dash_include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="wraper container-fluid">
        <section class="">
            <?php echo $__env->yieldContent('content'); ?>
        </section>
    </div>

    <?php echo $__env->make('dash_include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</section>


<?php echo $__env->make('dash_include.alertjs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('dash_include.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>