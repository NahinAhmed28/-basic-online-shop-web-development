<?php $__env->startSection('content'); ?>

    <!-- Page Content Start -->
    <!-- ================== -->
    <div class="main-grid">
        <div class="agile-grids">


            <!-- blank-page -->
            <div class="table-heading">
                <h2> Point Of Sale</h2>
            </div>
            <div class="row">
                <div class="col-md-8">
                    <p>Total Number of Users : <strong><?php echo e($number); ?></strong></p>
                </div>
                <div class="col-md-4">
                    <a class="btn btn-primary" href="<?php echo e(route('customers.add')); ?>">+Add Users</a>
                </div>
            </div>
            <hr>
            <div class="well">
                <div class="w3l-table-info">
                    <table id="customer" class="table">
                        <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th>Name</th>
                            <th>Position</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo $customer->id; ?></strong></td>
                                <td><strong><?php echo $customer->name; ?></strong></td>
                                <td><strong><?php echo $customer->position; ?></strong></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>









<?php echo $__env->make('layout.dash1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>