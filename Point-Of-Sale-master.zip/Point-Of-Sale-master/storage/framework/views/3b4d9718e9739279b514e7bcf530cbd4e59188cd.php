<head>

    <!-- Page Icon -->
    <link rel="icon" href="<?php echo e(asset('/upload/images/ink.png')); ?>" type="image/gif" sizes="20x20">
    <!-- Title -->
    <title><?php echo e($title); ?></title>

    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- bootstrap-css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin_dash_theme/css/bootstrap.css')); ?>">
    <!-- //bootstrap-css -->
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('admin_dash_theme/css/style.css')); ?>" rel='stylesheet' type='text/css' />
    <!-- font CSS -->
    <link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- font-awesome icons -->
    <link rel="stylesheet" href="<?php echo e(asset('admin_dash_theme/css/font.css')); ?>" type="text/css"/>
    <link href="<?php echo e(asset('admin_dash_theme/css/font-awesome.css')); ?>" rel="stylesheet">
    <!-- //font-awesome icons -->
    <script src="<?php echo e(asset('admin_dash_theme/js/jquery2.0.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_dash_theme/js/modernizr.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_dash_theme/js/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_dash_theme/js/screenfull.js')); ?>"></script>
    <script>
        $(function () {
            $('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

            if (!screenfull.enabled) {
                return false;
            }



            $('#toggle').click(function () {
                screenfull.toggle($('#container')[0]);
            });
        });
    </script>
    
    <script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
    <script type="text/javascript">CKEDITOR.replace( 'editor1' );</script>



<!-- tables -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_dash_theme/css/table-style.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_dash_theme/css/basictable.css')); ?>" />
    <script type="text/javascript" src="<?php echo e(asset('admin_dash_theme/js/jquery.basictable.min.js')); ?>"></script>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css')); ?>">

<!-- //tables -->

</head>