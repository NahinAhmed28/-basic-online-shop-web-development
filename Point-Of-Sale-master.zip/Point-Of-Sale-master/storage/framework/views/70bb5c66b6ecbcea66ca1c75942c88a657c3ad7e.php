<?php $__env->startSection('content'); ?>

    <!-- Page Content Start -->
    <!-- ================== -->
    <div class="main-grid">
        <div class="agile-grids">


            <!-- blank-page -->
            <div class="table-heading">
                <h2><?php echo $user->name; ?>'s Point Of Sale</h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <p>Number of Customers : <strong><?php echo e($num2); ?></strong></p>
                </div>
                <div class="col-md-6">
                    <p>Number of Products : <strong><?php echo e($num1); ?></strong></p>
                </div>
            </div>

            <hr>
            <div class="well">
                <div class="w3l-table-info">

                    <table id="table">
                        <thead>
                        <tr>
                            <th class="text-center">Order Id</th>
                            <th class="text-center">Category</th>
                            <th class="text-center">Number of Product</th>
                            <th class="text-center">Total sale</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><strong><?php echo $product->id; ?></strong></td>
                                <td class="text-center"><strong><?php echo $product->brand_name; ?></strong></td>
                                <td class="text-center"><strong><?php echo $product->quantity; ?></strong></td>
                                <td class="text-center"><strong><?php echo $product->total; ?></strong></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout.dash1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>