1. unzip using 7zip or winrar
2. create database named "shop_management"
3. install composer in the desktop 
3. migrate database inside project directory running command in console "php artisan migrate"
4. run command "php artisan db:seed"
5. for serve it in localhost "php artisan serve"

6. i) use username "admin@gmail.com" and
 password "12345678" for admin login


  ii) use username "user@gmail.com" and 
password "12345678" for user login
